# Magnetic-Wall
自己写的一个图片浏览软件,简洁方便.
